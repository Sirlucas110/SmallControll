# SmallControl
 Repositório referente ao Small Control- Projeto Integrador.
 Programa executado em HTML, CSS, PHP e AJAX.