<header class="bgcolor noPrint">
	<p class="font-text-sub text-center color-white">Bem vindo(a) <?= $_SESSION['user']?> ao Sistema <?= strtoupper($titleSite) ?></p>
</header>