<div class="divisor1">
	<p class="text-right noPrint"> <a href="#" onclick="window.print()" class="btn_search radius" title="Imprimir este relatório"><i class="fa fa-print"></i></a></p>
	<h1 class="font-text-min font-weight-medium"  style="margin: 10px 0 !important;">Relatório de Produtos</h1>
	<table style="width: 96% !important; margin: 10px 2% !important;">
		
		<?php for($i = 0; $i < 5; $i++): ?>
		<tr>
			<td>
				<p class="font-text-sub"><b>Produtos:</b></p>
				<p>Açucar Refinado 1KG</p>
			</td>
			
			<td>
				<p class="font-text-sub"><b>Quantidade:</b></p>
				<p>200 em estoque</p>
			</td>
			
			<td>
				<p class="font-text-sub"><b>Preço:</b></p>
				<p>R$ 25,00</p>
			</td>
			
			<td>
				<p class="font-text-sub"><b>Cadastrado:</b></p>
				<p>20/12/2022 - 17:24</p>
			</td>
			
		</tr>
		
		<?php endfor; ?>
	</table>
</div>